from pathlib import Path, PurePosixPath
import json, subprocess, hashlib, posixpath
out=Path(__file__).resolve().parent
src=Path('/tmp/6232-takeover/6537-explicit-orientation-hosted-native-remote-v1/artifacts/native-phase-37167463547-1')
repo='/home/louistrue/wt/6537-explicit-orientation-dispatch-session6503'
provenance=json.loads((src/'provenance.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
checks=[]
def check(ok,label):checks.append({'label':label,'passed':bool(ok)})
def git(*args):return subprocess.check_output(['git','-C',repo,*args],timeout=30)
all_trees=[]; all_blobs=set()
for snapshot in provenance['sources']:
 check(git('rev-parse',snapshot['head']+'^{tree}').decode().strip()==snapshot['tree'],'exact source tree '+snapshot['head'])
 tree={}
 for row in git('ls-tree','-r','-z',snapshot['head']).split(b'\0'):
  if not row:continue
  metadata,name=row.split(b'\t',1);mode,kind,blob=metadata.decode().split()
  if kind!='blob':raise ValueError('unsupported Git entry')
  tree[name.decode()]={'mode':mode,'blob':blob}; all_blobs.add(blob)
 all_trees.append((snapshot,tree))
# Read immutable object bytes once; no checkout mutation, build, model or remote filesystem access.
raw=subprocess.run(['git','-C',repo,'cat-file','--batch'],input=('\n'.join(sorted(all_blobs))+'\n').encode(),stdout=subprocess.PIPE,check=True,timeout=30).stdout
cursor=0; digests={}; links={}
while cursor<len(raw):
 end=raw.index(b'\n',cursor); blob,kind,size=raw[cursor:end].decode().split();size=int(size);cursor=end+1
 if kind!='blob':raise ValueError('missing/nonblob object')
 data=raw[cursor:cursor+size];cursor+=size
 if raw[cursor:cursor+1]!=b'\n':raise ValueError('invalid Git object frame')
 cursor+=1
 check(hashlib.sha1(b'blob '+str(size).encode()+b'\0'+data).hexdigest()==blob,'Git blob identity '+blob)
 digests[blob]=sha(data)
 if len(data)<4096:links[blob]=data
counts=[]
for snapshot,tree in all_trees:
 relative={path.removeprefix(snapshot['directory']+'/'):digest for path,digest in snapshot['files'].items()}
 check(set(relative)==set(tree),'complete tracked source census '+snapshot['head'])
 for name,row in tree.items():
  expected=digests[row['blob']]
  if row['mode']=='120000':
   target=links[row['blob']].decode();check(snapshot['links'].get(snapshot['directory']+'/'+name)==target,'Git source link '+snapshot['head']+'/'+name)
   resolved=name
   for depth in range(16):
    entry=tree[resolved]
    if entry['mode']!='120000':expected=digests[entry['blob']];break
    resolved=posixpath.normpath(posixpath.join(posixpath.dirname(resolved),links[entry['blob']].decode()))
    if resolved.startswith('../') or resolved.startswith('/'):raise ValueError('external source symlink cannot independently qualify')
   else:raise ValueError('source symlink depth bound')
  check(relative.get(name)==expected,'full Git source SHA '+snapshot['head']+'/'+name)
 counts.append({'head':snapshot['head'],'files':len(tree),'links':sum(row['mode']=='120000' for row in tree.values())})
attachment={'status':'PASS_FULL_GIT_SOURCE_AUDIT' if all(c['passed'] for c in checks) else 'AUDIT_FINDINGS','sources':counts,'uniqueGitBlobs':len(all_blobs),'checks':checks,'failedChecks':[c for c in checks if not c['passed']],'scope':'All tracked source files independently rehashed from immutable Git objects, including symlink targets. Actual remote installed tools, sysroot, binary and registry paths are retained producing/final-freeze receipts, not independently rehashed after teardown; declared native closure limitations remain.'}
(out/'git-source-attachment.json').write_text(json.dumps(attachment,indent=2)+'\n')
print(json.dumps({'status':attachment['status'],'checks':len(checks),'sources':counts,'failedChecks':attachment['failedChecks']},indent=2))
