Current disposition: **do not merge the current candidate**. The fresh integrated default-worker SDK comparison [run 37194313221](https://github.com/LTplus-AG/ifc-lite/actions/runs/37194313221) completed all 56 samples and 28 pairs. ISSUE129 improved in all five A/B pairs (paired median −2.145%), but Holter regressed in all five (paired median +1.772%, range +0.957% to +3.881%). House and O-S1 were mixed. All observed produced CPU identities and complete diagnostics match; no samples were dropped. This is a performance blocker under the maintainer’s no-regressions requirement.

The measured subjects remain `8ab47142562a79862df6d14700a39723351f00df` → `89d7976bb9f0ab02b82052468e2d1b052502eb7d`. Current head `4361d08d92c03ea53aaaa940ae6fde8533f7f2f1` preserves that SDK source after main integration; it is not a newly measured binary. Fresh functional CI remains pending. Earlier qualified cohorts stay separate. The regression’s mechanism is not established; no universal speed, full-viewer or physical-memory benefit is claimed.

Refs #6537

Known-explicit calls share the same private adaptive orientation entrypoint as the general dispatcher's explicit arm. Argument order, sign conversion, degeneracy and mixed-point fallbacks remain unchanged. Existing predicate tests are preserved; 216 independent rational permutation controls and final workspace/strict Clippy checks pass.

Both comparisons measure literal BASE `187a72e3302447fc49f2264111501223238a24a7` against CAND `672f1e09c06ce777507244d2f2c4403d7b38c098`. SDK run [37167109427](https://github.com/LTplus-AG/ifc-lite/actions/runs/37167109427) qualifies 56 samples/28 pairs with produced CPU identities/full diagnostics: ISSUE129 improves in all five observed pairs, others are mixed. Native run [37182263516](https://github.com/LTplus-AG/ifc-lite/actions/runs/37182263516) qualifies 17 pairs/34 processes with strict summary/FD/source/resource/cleanup checks; changes are small and mixed, with no consistent native speed win. No universal, full-viewer, physical-memory, isolated-dispatch or instruction benefit is claimed.

Correctness failures and prior native refusals stay immutable; existing evidence child [#6792](https://github.com/LTplus-AG/ifc-lite/pull/6792) retains raw receipts and scopes. This docs-only successor preserves all eight measured Rust/test paths. Final-head CI and review are being collected. Merge waits for all required checks and resolution of every actionable review finding.


<!-- This is an auto-generated comment: release notes by coderabbit.ai -->

## Summary by CodeRabbit

* **Performance**
  * Geometry operations using explicit point coordinates now take a more direct path. Benchmarks showed improvements in some tested workflows, while results varied across other workloads; no universal speedup is claimed.
* **Reliability**
  * Expanded geometry-predicate checks cover exact results, point and plane relationships, and randomized cases.

<!-- end of auto-generated comment: release notes by coderabbit.ai -->